# Linked-Kitty

This challenge was to recreate a linked-in page using React and styled-components.

Deployed here: https://focused-brown-312623.netlify.com/



This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app).

